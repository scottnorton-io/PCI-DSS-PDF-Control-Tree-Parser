"""PCI DSS PDF Control Tree Parser package.

All outputs are draft artifacts and MUST be reviewed and validated
by a qualified PCI DSS assessor before use in any formal deliverable.
"""
